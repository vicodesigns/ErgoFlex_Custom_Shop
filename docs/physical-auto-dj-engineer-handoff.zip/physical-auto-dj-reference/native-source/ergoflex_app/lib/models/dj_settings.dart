// models/dj_settings.dart
// Auto DJ "You Are The DJ" — value objects for the custom DJ program,
// Flash Comfort, and the settings-sheet bootstrap payload.
//
// Mirrors the Go services.DJSettings / DJSettingsOverview shapes
// (GET/PUT /api/v1/led/music-mode/auto-dj/settings and
//  GET/PUT /api/v1/led/music-mode/flash-comfort). Follows the
// VoiceTierPreferences pattern: Equatable value objects with their own
// endpoints, deliberately NOT wired through SettingsBloc.

import 'package:equatable/equatable.dart';

import 'dj_look_event.dart';

/// Global Flash Comfort preference. Internal wire values are
/// off/reduced/minimal; the UI labels `off` as "Standard" (never "Off" —
/// users would read that as "flashing is off").
enum FlashComfort {
  off,
  reduced,
  minimal;

  String get wire => name; // 'off' | 'reduced' | 'minimal'

  static FlashComfort fromWire(String? value) {
    switch (value) {
      case 'reduced':
        return FlashComfort.reduced;
      case 'minimal':
        return FlashComfort.minimal;
      default:
        return FlashComfort.off;
    }
  }
}

/// DJ look kinds (lockstep with the Go DJLookKind* constants).
class DJLookKind {
  static const builtin = 'builtin';
  static const musicFavorite = 'music_favorite';
  static const customPreset = 'custom_preset';
}

/// One pool entry as authored by the user: a builtin effect or a reference
/// to a music favorite / music-mode custom preset, with its usage weight
/// 1-4 (Rare/Sometimes/Often/Favorite). Weight-0 ("Off") entries are never
/// serialized — absent means Off.
class DJLookRef extends Equatable {
  final String kind;
  final int? viz; // builtin: 0-9 (0 = Spectrum, valid!)
  final int? ix;
  final String? refId; // favorite id (decimal string) / preset UUID
  final int weight; // 1-4

  const DJLookRef({
    required this.kind,
    this.viz,
    this.ix,
    this.refId,
    required this.weight,
  });

  /// Canonical identity, matching the server's stable IDs
  /// ("builtin:5" / "music_favorite:12" / "custom_preset:<uuid>").
  String get stableId =>
      kind == DJLookKind.builtin ? 'builtin:$viz' : '$kind:$refId';

  factory DJLookRef.fromJson(Map<String, dynamic> json) => DJLookRef(
        kind: json['kind'] as String? ?? '',
        viz: (json['viz'] as num?)?.toInt(),
        ix: (json['ix'] as num?)?.toInt(),
        refId: json['ref_id'] as String?,
        weight: (json['weight'] as num?)?.toInt() ?? 0,
      );

  Map<String, dynamic> toJson() => {
        'kind': kind,
        if (viz != null) 'viz': viz,
        if (ix != null) 'ix': ix,
        if (refId != null && refId!.isNotEmpty) 'ref_id': refId,
        'weight': weight,
      };

  @override
  List<Object?> get props => [kind, viz, ix, refId, weight];
}

/// The full custom program (version 1).
class DJSettings extends Equatable {
  static const int currentVersion = 1;
  static const int maxSelections = 40;

  /// Colour Dynamics modes. The wire values, not display strings — these are
  /// sent to the backend verbatim.
  static const String dynamicsOff = 'off';
  static const String dynamicsStory = 'story';
  static const String dynamicsWide = 'wide';
  static const List<String> dynamicsModes = [
    dynamicsOff,
    dynamicsStory,
    dynamicsWide,
  ];

  final int version;
  final List<DJLookRef> looks;
  final int switchBars; // 4 | 8 | 16
  final bool burstsOn;
  final bool randomizeOn;

  /// Colour Dynamics: one three-state control, not two toggles.
  ///
  /// `off` | `story` | `wide`. Story is the four curated moods that return to
  /// neutral; wide ranges the same five firmware fields further. It is one
  /// control because both settings drive the SAME five fields, and two
  /// producers of one field means whichever wrote last wins and neither can
  /// release its own contribution.
  ///
  final String dynamicsMode;

  /// The legacy mirror the backend keeps written for older clients.
  ///
  /// DERIVED, never stored: making it a field would let a caller construct a
  /// settings object whose two halves disagree — `colorStory: true` beside
  /// `dynamicsMode: off` — which is precisely the two-sources-for-one-setting
  /// problem collapsing Color Story into a three-state mode removed.
  bool get colorStory => dynamicsMode != dynamicsOff;

  /// Varies each effect's own two sliders — the pair the UI labels differently
  /// under every effect (Twinkle Fade, Balance, Wave Width). Curated per
  /// effect, because those two knobs mean something different under each one.
  final bool remixSliders;

  /// Shapes the Colour Bursts overlay: rate, spectrum, zone and the randomize
  /// cadence. It never switches bursts ON — [burstsOn] and [randomizeOn] stay
  /// yours, and Flash Comfort still clears them.
  final bool remixBursts;

  /// Retunes how sharply the desk answers the music — gamma, attack/decay,
  /// beat boost and the pulse family. Response, not appearance.
  final bool remixPhysics;

  /// Runs different effects on different physical shelves at the same time,
  /// drawn from a curated recipe catalogue.
  final bool composeTiers;

  /// Lets the show play one of your presets' colours under a different effect.
  ///
  /// Lives in this settings blob rather than a standalone user setting because
  /// the blob is read only for the Custom program, and remixing is meaningless
  /// without your own presets to remix.
  final bool remixOn;

  const DJSettings({
    this.version = currentVersion,
    required this.looks,
    this.switchBars = 8,
    this.burstsOn = false,
    this.randomizeOn = false,
    this.remixOn = false,
    this.dynamicsMode = dynamicsOff,
    this.remixSliders = false,
    this.remixBursts = false,
    this.remixPhysics = false,
    this.composeTiers = false,
  });

  factory DJSettings.fromJson(Map<String, dynamic> json) => DJSettings(
        version: (json['version'] as num?)?.toInt() ?? currentVersion,
        looks: ((json['looks'] as List?) ?? const [])
            .whereType<Map<String, dynamic>>()
            .map(DJLookRef.fromJson)
            .toList(),
        switchBars: (json['switch_bars'] as num?)?.toInt() ?? 8,
        burstsOn: json['bursts_on'] as bool? ?? false,
        randomizeOn: json['randomize_on'] as bool? ?? false,
        remixOn: json['remix_on'] as bool? ?? false,
        // Degrade, never fail. A blob written by a newer build can name a mode
        // this one does not know, and refusing it would make the sheet
        // unopenable — a value nobody can see is a value nobody can correct.
        // The backend does the same on its read path.
        dynamicsMode: _readDynamicsMode(json),
        remixSliders: json['remix_sliders'] as bool? ?? false,
        remixBursts: json['remix_bursts'] as bool? ?? false,
        remixPhysics: json['remix_physics'] as bool? ?? false,
        composeTiers: json['compose_tiers'] as bool? ?? false,
      );

  static String _readDynamicsMode(Map<String, dynamic> json) {
    final raw = json['dynamics_mode'] as String?;
    if (raw != null && dynamicsModes.contains(raw)) return raw;
    return (json['color_story'] as bool? ?? false) ? dynamicsStory : dynamicsOff;
  }

  Map<String, dynamic> toJson() => {
        'version': version,
        'looks': looks.map((l) => l.toJson()).toList(),
        'switch_bars': switchBars,
        'bursts_on': burstsOn,
        'randomize_on': randomizeOn,
        'remix_on': remixOn,
        'dynamics_mode': dynamicsMode,
        // Kept written so an older backend or client still reads a `wide`
        // show as dynamics-enabled rather than as off.
        'color_story': dynamicsMode != dynamicsOff,
        'remix_sliders': remixSliders,
        'remix_bursts': remixBursts,
        'remix_physics': remixPhysics,
        'compose_tiers': composeTiers,
      };

  @override
  List<Object?> get props => [
        version,
        looks,
        switchBars,
        burstsOn,
        randomizeOn,
        remixOn,
        dynamicsMode,
        remixSliders,
        remixBursts,
        remixPhysics,
        composeTiers,
      ];
}

/// Tri-state firmware capabilities: null = not yet probed (probing happens
/// at music activation). The sheet renders unknown PERMISSIVELY — layer FX
/// stay visible; only an explicit `false` hides/filters them.
class DJCapabilities extends Equatable {
  final bool? layerFx;
  final bool? colorDynamics;
  final bool? colorBursts;

  const DJCapabilities({this.layerFx, this.colorDynamics, this.colorBursts});

  factory DJCapabilities.fromJson(Map<String, dynamic>? json) =>
      DJCapabilities(
        layerFx: json?['layer_fx'] as bool?,
        colorDynamics: json?['color_dynamics'] as bool?,
        colorBursts: json?['color_bursts'] as bool?,
      );

  /// Unknown counts as usable (permissive) — mirrors the backend preflight.
  bool get layerFxUsable => layerFx != false;
  bool get colorDynamicsUsable => colorDynamics != false;
  bool get colorBurstsUsable => colorBursts != false;

  @override
  List<Object?> get props => [layerFx, colorDynamics, colorBursts];
}

/// One row of the settings sheet's authoritative pool list.
class DJEligiblePoolEntry extends Equatable {
  final String kind;
  final String refId; // empty for builtins
  final int? viz;
  final String label;
  final bool flashHeavy;
  final bool resolvable;
  final String reason; // 'deleted' | 'unusable_payload' | ''
  final int currentWeight; // 0 = Off / not selected

  const DJEligiblePoolEntry({
    required this.kind,
    this.refId = '',
    this.viz,
    required this.label,
    this.flashHeavy = false,
    this.resolvable = true,
    this.reason = '',
    this.currentWeight = 0,
  });

  String get stableId =>
      kind == DJLookKind.builtin ? 'builtin:$viz' : '$kind:$refId';

  factory DJEligiblePoolEntry.fromJson(Map<String, dynamic> json) =>
      DJEligiblePoolEntry(
        kind: json['kind'] as String? ?? '',
        refId: json['ref_id'] as String? ?? '',
        viz: (json['viz'] as num?)?.toInt(),
        label: json['label'] as String? ?? '',
        flashHeavy: json['flash_heavy'] as bool? ?? false,
        resolvable: json['resolvable'] as bool? ?? false,
        reason: json['reason'] as String? ?? '',
        currentWeight: (json['current_weight'] as num?)?.toInt() ?? 0,
      );

  @override
  List<Object?> get props =>
      [kind, refId, viz, label, flashHeavy, resolvable, reason, currentWeight];
}

/// The DJ's current look ("Now: Tower") from status / the settings GET —
/// available immediately, without waiting for the next WS event.
class DJNowPlaying extends Equatable {
  final int viz;
  final String refId;

  /// The pool entry behind [refId] — see [DjLookEvent.baseRefId]. Match the
  /// sheet's "playing now" card on this, so a remix still lights up the
  /// preset it was built from.
  final String baseRefId;
  final String label;
  final String lookKind;
  final String program;
  final String reason;

  /// What each of the five physical tiers is rendering, as visualization ids.
  /// Always RESOLVED — five concrete effects, never "inherit" — so an
  /// uncomposed look is the base effect five times. Empty only from an API
  /// predating tier composition.
  final List<int> tierPlan;
  final String recipeId;
  final String recipeName;

  /// Which variation recipe each family contributed, empty when it
  /// contributed nothing. The backend stamps these only when the write
  /// actually landed, so an empty value means "nothing was sent", never
  /// "something was sent and we lost track of it".
  /// The BASE look's slider draw. [tierSliderIds] carries what each REPLACED
  /// tier drew for its own effect — a different question, and one a single id
  /// cannot answer for a mixed composition.
  final String sliderId;
  final List<String> tierSliderIds;
  final String burstRecipeId;
  final String randomizeRecipeId;
  final String physicsRecipeId;

  /// False while the desk's layer-FX capability was unknown, meaning it may
  /// not have rendered [tierPlan] as described.
  final bool planVerified;

  /// When the server switched TO this look. Sent by the settings-sheet
  /// bootstrap (GET .../auto-dj/settings), which serializes the whole
  /// server-side DJNowPlaying struct — but NOT by the live `music_dj_look`
  /// WS frame, which is a hand-built map that never grew this key. A look
  /// Carried on the `music_dj_look` frame since 2026-08-23, so
  /// [fromLookEvent] round-trips the SERVER's switch instant. It stays
  /// nullable because an API predating that field sends none — and a caller
  /// that gets null must send NO claim rather than substituting its own
  /// clock. Inventing one is what made `agreed` meaningless before the field
  /// existed: a fabricated instant can never match the server's, so every
  /// rating recorded a disagreement that had not happened.
  ///
  /// Round-tripped, never guessed at, because the rating endpoint uses it
  /// only to CROSS-CHECK against its own authoritative current look — a
  /// wrong guess here is worse than an absent one.
  final DateTime? since;

  const DJNowPlaying({
    required this.viz,
    this.refId = '',
    this.baseRefId = '',
    this.label = '',
    this.lookKind = '',
    this.program = '',
    this.reason = '',
    this.tierPlan = const [],
    this.recipeId = '',
    this.recipeName = '',
    this.sliderId = '',
    this.tierSliderIds = const [],
    this.burstRecipeId = '',
    this.randomizeRecipeId = '',
    this.physicsRecipeId = '',
    this.planVerified = false,
    this.since,
  });

  /// Rebuilds the snapshot from a live look event.
  ///
  /// Both routes to a DJNowPlaying — this one and [DJNowPlaying.fromJson] for
  /// the sheet bootstrap — must carry the SAME fields, or the sheet describes
  /// a look one way until the next switch and another way after it. That has
  /// already happened once with baseRefId, which is why this is a named
  /// constructor rather than a hand-assembled literal at the call site.
  ///
  /// [since] is the one deliberate exception: the WS frame [e] came from has
  /// no `since` key (see [DJNowPlaying.since]), so there is nothing to carry
  /// here. A caller that observed the switch live may pass the moment it saw
  /// this event as a best-effort stand-in — never a guess at the server's
  /// actual switch time.
  factory DJNowPlaying.fromLookEvent(DjLookEvent e, {DateTime? since}) =>
      DJNowPlaying(
        viz: e.viz,
        refId: e.refId,
        baseRefId: e.baseRefId,
        label: e.label,
        lookKind: e.lookKind,
        program: e.program,
        reason: e.reason,
        tierPlan: e.tierPlan,
        recipeId: e.recipeId,
        recipeName: e.recipeName,
        sliderId: e.sliderId,
        tierSliderIds: e.tierSliderIds,
        burstRecipeId: e.burstRecipeId,
        randomizeRecipeId: e.randomizeRecipeId,
        physicsRecipeId: e.physicsRecipeId,
        planVerified: e.planVerified,
        since: since,
      );

  factory DJNowPlaying.fromJson(Map<String, dynamic> json) => DJNowPlaying(
        viz: (json['viz'] as num?)?.toInt() ?? 0,
        refId: json['ref_id'] as String? ?? '',
        // Falls back to ref_id so an API predating remix still highlights
        // correctly during a staggered rollout.
        baseRefId: json['base_ref_id'] as String? ??
            json['ref_id'] as String? ??
            '',
        label: json['label'] as String? ?? '',
        lookKind: json['look_kind'] as String? ?? '',
        program: json['program'] as String? ?? '',
        reason: json['reason'] as String? ?? '',
        tierPlan: ((json['tier_plan'] as List?) ?? const [])
            .whereType<num>()
            .map((v) => v.toInt())
            .toList(),
        recipeId: json['recipe_id'] as String? ?? '',
        recipeName: json['recipe_name'] as String? ?? '',
        sliderId: json['slider_id'] as String? ?? '',
        tierSliderIds: ((json['tier_slider_ids'] as List?) ?? const [])
            .map((v) => v as String? ?? '')
            .toList(),
        burstRecipeId: json['burst_recipe_id'] as String? ?? '',
        randomizeRecipeId: json['randomize_recipe_id'] as String? ?? '',
        physicsRecipeId: json['physics_recipe_id'] as String? ?? '',
        planVerified: json['plan_verified'] as bool? ?? false,
        since: DateTime.tryParse(json['since'] as String? ?? ''),
      );

  @override
  List<Object?> get props => [
        viz,
        refId,
        baseRefId,
        label,
        lookKind,
        program,
        reason,
        tierPlan,
        recipeId,
        recipeName,
        sliderId,
        tierSliderIds,
        burstRecipeId,
        randomizeRecipeId,
        physicsRecipeId,
        planVerified,
        since,
      ];
}

/// GET /led/music-mode/auto-dj/settings — the sheet's single bootstrap.
/// Whether the caller owns the live music session and which DJ program is
/// conducting — the sheet uses this to warn when the saved mix isn't what's
/// actually playing ("the DJ is playing Party, not your mix") and to offer
/// the one-tap switch.
class DJSessionInfo extends Equatable {
  final bool sessionActive; // the caller owns the active music session
  final bool djEnabled;
  final String program; // running DJ program key ('' when off)

  const DJSessionInfo({
    this.sessionActive = false,
    this.djEnabled = false,
    this.program = '',
  });

  factory DJSessionInfo.fromJson(Map<String, dynamic>? json) {
    if (json == null) return const DJSessionInfo();
    return DJSessionInfo(
      sessionActive: json['session_active'] == true,
      djEnabled: json['dj_enabled'] == true,
      program: (json['program'] as String?) ?? '',
    );
  }

  @override
  List<Object?> get props => [sessionActive, djEnabled, program];
}

class DJSettingsOverview extends Equatable {
  final DJSettings? settings; // null = never configured
  final FlashComfort flashComfort;

  /// Phrase rotations wait for the next beat when the analyzer holds a tempo
  /// lock. Global like [flashComfort] — it applies to every program, not only
  /// the custom one.
  final bool beatAlign;
  final DJCapabilities capabilities;
  final DJSessionInfo session;
  final List<DJEligiblePoolEntry> eligiblePool;
  final DJNowPlaying? nowPlaying;
  final Map<String, int> nowPlayingCounts;

  const DJSettingsOverview({
    this.settings,
    this.flashComfort = FlashComfort.off,
    this.beatAlign = false,
    this.capabilities = const DJCapabilities(),
    this.session = const DJSessionInfo(),
    this.eligiblePool = const [],
    this.nowPlaying,
    this.nowPlayingCounts = const {},
  });

  factory DJSettingsOverview.fromJson(Map<String, dynamic> json) {
    final settingsJson = json['settings'];
    final npJson = json['now_playing'];
    return DJSettingsOverview(
      settings: settingsJson is Map<String, dynamic>
          ? DJSettings.fromJson(settingsJson)
          : null,
      flashComfort: FlashComfort.fromWire(json['flash_comfort'] as String?),
      // Absent decodes to false, so an app talking to a backend from before
      // migration 245 shows the feature off rather than throwing.
      beatAlign: json['beat_align'] as bool? ?? false,
      capabilities: DJCapabilities.fromJson(
          json['capabilities'] as Map<String, dynamic>?),
      session:
          DJSessionInfo.fromJson(json['session'] as Map<String, dynamic>?),
      eligiblePool: ((json['eligible_pool'] as List?) ?? const [])
          .whereType<Map<String, dynamic>>()
          .map(DJEligiblePoolEntry.fromJson)
          .toList(),
      nowPlaying: npJson is Map<String, dynamic>
          ? DJNowPlaying.fromJson(npJson)
          : null,
      nowPlayingCounts: ((json['now_playing_counts'] as Map?) ?? const {})
          .map((k, v) => MapEntry(k.toString(), (v as num).toInt())),
    );
  }

  @override
  List<Object?> get props => [
        settings,
        flashComfort,
        beatAlign,
        capabilities,
        session,
        eligiblePool,
        nowPlaying,
        nowPlayingCounts,
      ];
}
