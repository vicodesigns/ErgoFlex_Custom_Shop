ErgoFlex LA Tech Week 3D viewer

Extract this ZIP inside wp-content/uploads/2026/promo in your hosting File Manager.
It creates the ergoflex-demo subfolder.
Then check https://ergoflexdesk.com/wp-content/uploads/2026/promo/ergoflex-demo/product-demo.html
The LA Tech Week Divi button must use /wp-content/uploads/2026/promo/ergoflex-demo/product-demo.html
for its Hosted 3D viewer URL.

The model is fetched from the existing public Store/model/full.glb URL.
This bundle bakes the Studio tilt group with 32 moving parts.
If the Studio tilt rig changes again, rebuild this bundle and upload again.
