// Reuse the configurator's real 3D canvas and its ErgoFlex app remote.
// Other controls stay in the DOM for the shared studio engine.
const demo = document.createElement('section');
demo.id = 'event-demo';
demo.innerHTML = `<div class="demo-top"><strong>Explore ErgoFlex in 3D</strong><label>Backdrop <select id="demo-backdrop"><option value="gallery">Gallery</option><option value="warm">Warm studio</option><option value="slate" selected>Slate studio</option></select></label></div><div id="demo-stage"><div id="demo-viewer"></div><div id="demo-remote" aria-label="Interactive ErgoFlex app controls"></div></div><p class="demo-note" role="status">Loading the workstation…</p>`;
document.body.append(demo);
document.querySelector('#demo-viewer').append(document.querySelector('#viewer-shell'));
const start = Date.now();
const ready = setInterval(() => {
  const api = window.ErgoFlex;
  const dock = document.querySelector('#motion-dock');
  if (!api?.loadedModel || !api?.wheelRigs.length || !dock || getComputedStyle(document.querySelector('#loader')).display !== 'none') {
    if (Date.now()-start > 90000) {clearInterval(ready);demo.querySelector('.demo-note').textContent='The 3D model could not load. You can still watch the desk demonstrations below.';}
    return;
  }
  clearInterval(ready);
  api.setRoomScene('product',false);
  api.setAutoRotate(false);
  api.setRemoteTheme('dark');
  document.querySelector('#demo-remote').append(dock);
  dock.dataset.mode = 'docked';
  dock.dataset.sized = 'true';
  dock.dataset.shape = 'narrow-portrait';
  dock.style.setProperty('--dock-w', '100%');
  dock.style.setProperty('--dock-h', '100%');
  dock.style.setProperty('--remote-unit', '4px');
  dock.style.setProperty('--remote-scale', '1');
  if (dock.classList.contains('collapsed')) document.querySelector('#motion-dock-toggle')?.click();
  const backdrop = document.querySelector('#demo-backdrop');
  backdrop.value=document.querySelector('#studio-environment').value;
  backdrop.onchange=()=>{const original=document.querySelector('#studio-environment');original.value=backdrop.value;original.dispatchEvent(new Event('change'));};
  demo.querySelector('.demo-note').textContent='Drag the desk to rotate · Scroll or pinch to zoom · Use the ErgoFlex app controls to move the 3D workstation.';
  window.dispatchEvent(new Event('resize'));
  requestAnimationFrame(()=>document.querySelector('#fit-view')?.click());
},150);
